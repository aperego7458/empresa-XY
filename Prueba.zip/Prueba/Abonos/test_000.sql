/*
Navicat MySQL Data Transfer

Source Server         : Local
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : test_000

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2017-10-19 07:43:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for abonos
-- ----------------------------
DROP TABLE IF EXISTS `abonos`;
CREATE TABLE `abonos` (
  `id_abono` int(11) NOT NULL AUTO_INCREMENT,
  `creditos_id_credito` int(25) DEFAULT NULL,
  `valor_abono` float DEFAULT NULL,
  `abono_capital` float DEFAULT NULL,
  `intereses` float DEFAULT NULL,
  `saldo` float DEFAULT NULL,
  `fecha_abono` date DEFAULT NULL,
  PRIMARY KEY (`id_abono`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of abonos
-- ----------------------------

-- ----------------------------
-- Table structure for clientes
-- ----------------------------
DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `documento` int(25) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`documento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of clientes
-- ----------------------------
INSERT INTO `clientes` VALUES ('1234', 'Juan Peñalosa', 'Calle 12 # 34 - 56', '5551234');
INSERT INTO `clientes` VALUES ('4321', 'Maria Cardona', 'Calle 21 # 4 - 78', '6655561');

-- ----------------------------
-- Table structure for creditos
-- ----------------------------
DROP TABLE IF EXISTS `creditos`;
CREATE TABLE `creditos` (
  `id_credito` int(25) NOT NULL AUTO_INCREMENT,
  `clientes_documento` int(25) DEFAULT NULL,
  `valor_credito` int(255) DEFAULT NULL,
  `fecha_desembolso` date DEFAULT NULL,
  PRIMARY KEY (`id_credito`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of creditos
-- ----------------------------
INSERT INTO `creditos` VALUES ('1', '1234', '1000000', '2017-01-15');
INSERT INTO `creditos` VALUES ('2', '4321', '2000000', '2017-02-13');
SET FOREIGN_KEY_CHECKS=1;
