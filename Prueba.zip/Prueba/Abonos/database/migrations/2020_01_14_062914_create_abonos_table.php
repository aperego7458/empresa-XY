<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAbonosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('abonos', function (Blueprint $table) {
            $table->bigIncrements('id_abono');
            $table->float('creditos_id_credito');
            $table->float('valor_abono');
            $table->float('abono_capital');
            $table->double('intereses');
            $table->float('saldo');
            $table->date('fecha_abono');
            $table->timestamps();

            $table->foreign('creditos_id_credito')->references('id_credito')->on('creditos')
                ->onUpdate('cascade')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('abonos');
    }
}
